from mastodon import Mastodon
import json
from datetime import datetime, timezone
from tqdm import tqdm
import requests
import os

STATE_FILE = "mastodon_state.json"
OUTPUT_FILE = "mastodon_posts.jsonl"

def config(k):
    """
    To read mastodon-config file retrieving CLIENT_ID and CLIENT_SECRET for security

    Return:
    - (str) the value of parameter k from config.yaml
    """
    with open(f"/configs/default/mastodon-config/{k}", 'r') as f: # open the file in cluster
        return f.read() # return the value that have been read


# Initialize Mastodon client with saved credentials
mastodon = Mastodon(
    access_token=config("ACCESS_TOKEN"),
    api_base_url=config("API_BASE_URL")
)


# Load State Functions, based on timestamp and last max id
def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return {"last_max_id": None, "last_timestamp": None}

def save_state(last_max_id, last_timestamp):
    with open(STATE_FILE, "w") as f:
        json.dump({
            "last_max_id": last_max_id,
            "last_timestamp": last_timestamp
        }, f)


# Sentiment Analysis - update using reddit_sentiment
def compute_sentiment_remote(text):
    try:
        response = requests.get(
            url="http://router.fission/reddit-sentiment-2",
            json={"text": text},
            timeout=5
        )
        return response.json() if response.status_code == 200 else {"error": f"HTTP {response.status_code}"}
    except Exception as e:
        return {"error": str(e)}


# Harvest posts from public timeline
def harvest_public_posts(start_date, max_posts=100): #max_posts can be adjusted, official limit only 40 at a time
    """
    Harvest up to max_posts from the PUBLIC timeline since start_date.
    Batch of up to 40 posts.
    """
    collected = []
    state = load_state()
    max_id = state.get("last_max_id")
    last_ts = state.get("last_timestamp") or start_date.timestamp()

    while len(collected) < max_posts:
        batch = mastodon.timeline_public(limit=40, max_id=max_id, local=True)
        if not batch:
            break

        for status in tqdm(batch, desc=f"Batch {(len(collected)//40)+1}", unit="toots", leave=False):
            ts = status.created_at.replace(tzinfo=timezone.utc).timestamp()
            if ts < last_ts:
                save_state(max_id, last_ts)
                return collected
            collected.append(status)

        max_id = int(batch[-1].id) - 1
        last_ts = max(last_ts, batch[-1].created_at.replace(tzinfo=timezone.utc).timestamp())

    save_state(max_id, last_ts)
    return "OK"


# Clean post
def clean_post(status):
    """Convert a Mastodon.Status into JSON + scores dict."""
    content = status.content
    favs = status.favourites_count
    reblogs = status.reblogs_count
    replies = getattr(status, 'replies_count', 0)

    return {
        'id': status.id,
        'source': 'mastodon',
        'created_at': status.created_at.isoformat(),
        'account': status.account.acct,
        'content': content,
        'language': status.language,
        'num_favourites': favs,
        'num_reblogs': reblogs,
        'num_replies': replies,
        'sentiment': compute_sentiment_remote(content)
    }


def main():
    start_date = datetime(2024, 1, 1, tzinfo=timezone.utc) # adjust as needed
    posts = harvest_public_posts(start_date)

    print(f"Total posts harvested: {len(posts)}")

    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f:
        for status in tqdm(posts, desc="Saving posts", unit="posts"):
            record = clean_post(status)
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            
            # Respond to unifying data
            respon_unify = requests.get('http://router.fission/data-unify-2', json=record)

if __name__ == '__main__':
    main()
