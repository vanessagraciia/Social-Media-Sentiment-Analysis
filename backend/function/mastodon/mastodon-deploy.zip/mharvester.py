from typing import List, Dict, Any
from flask import current_app, request
from mastodon import Mastodon, MastodonError
import json
import time
import logging


def main() -> str:
    """Harvest recent public posts from Mastodon timeline.

    Handles:
    - Mastodon API client initialization
    - Timeline pagination using since_id
    - Rate limiting with 5-second collection window
    - JSON serialization of post data

    Returns:
        JSON string containing list of post objects

    Raises:
        MastodonError: For API communication failures
        JSONDecodeError: If response parsing fails
    """
    # Initialize Mastodon client with type annotation
    m: Mastodon = Mastodon(
        api_base_url='https://mastodon.au',
        request_timeout=10
    )

    # Get initial anchor post
    last_post: Dict[str, Any] = m.timeline(
        timeline='public',
        since_id=None,
        limit=1,
        remote=True
    )[0]
    lastid: int = last_post['id']

    # Allow time window for new posts
    time.sleep(5)

    # Fetch new posts since anchor
    posts: List[Dict[str, Any]] = m.timeline(
        timeline='public',
        since_id=lastid,
        remote=True
    )

    # Structured logging with harvest metrics
    current_app.logger.info(
        f'Harvested {len(posts)} posts '
        f'(since_id: {lastid}, time_window: 5s)'
        # print(f'[LOG] Harvested {len(posts)} posts (since_id: {lastid}, time_window: 5s)')
    )

    return json.dumps(posts, default=str)
